# MyFin Mobile Sprint 2.1 — Foundation UI

Bu paket mevcut Flutter projenin `lib/` klasörünü değiştirir.

## Kurulum

```bash
cd ~/Downloads/myfin_mobile
cp -R ~/Downloads/myfin_mobile_sprint_2_1/lib/* lib/
flutter run
```

## İçerik

- Light/Dark tema altyapısı
- Hawaiian Ocean renk paleti
- iOS tarzı bottom navigation
- Dashboard iskeleti
- Portföy, Varlık Ekle, Analiz, Ayarlar placeholder ekranları
- MyCard, MetricCard, SectionTitle bileşenleri
