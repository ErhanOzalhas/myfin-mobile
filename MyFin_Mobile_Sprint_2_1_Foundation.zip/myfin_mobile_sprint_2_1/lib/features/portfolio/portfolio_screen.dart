import 'package:flutter/material.dart';
import '../../core/widgets/my_card.dart';

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        Text('Portföy', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        SizedBox(height: 16),
        MyCard(child: Text('Kategori ve varlık görünümleri Sprint 4’te Supabase ile bağlanacak.')),
      ],
    );
  }
}
