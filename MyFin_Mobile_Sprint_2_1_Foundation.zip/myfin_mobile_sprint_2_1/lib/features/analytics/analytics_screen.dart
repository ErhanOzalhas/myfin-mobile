import 'package:flutter/material.dart';
import '../../core/widgets/my_card.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        Text('Analiz', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        SizedBox(height: 16),
        MyCard(child: Text('Performans grafikleri ve risk özeti burada olacak.')),
      ],
    );
  }
}
