import 'package:flutter/material.dart';
import '../../core/widgets/my_card.dart';

class AddAssetScreen extends StatelessWidget {
  const AddAssetScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        Text('Varlık Ekle', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        SizedBox(height: 16),
        MyCard(child: Text('İlk alış formu Sprint 5’te eklenecek.')),
      ],
    );
  }
}
