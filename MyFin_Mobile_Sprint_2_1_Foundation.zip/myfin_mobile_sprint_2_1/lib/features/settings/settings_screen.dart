import 'package:flutter/material.dart';
import '../../core/widgets/my_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        Text('Ayarlar', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        SizedBox(height: 16),
        MyCard(child: Text('Tema, Face ID ve bildirim ayarları Sprint 3’te eklenecek.')),
      ],
    );
  }
}
