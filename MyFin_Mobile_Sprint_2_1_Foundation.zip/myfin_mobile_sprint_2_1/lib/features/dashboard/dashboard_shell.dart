import 'package:flutter/material.dart';
import '../portfolio/portfolio_screen.dart';
import '../add_asset/add_asset_screen.dart';
import '../analytics/analytics_screen.dart';
import '../settings/settings_screen.dart';
import 'dashboard_screen.dart';

class DashboardShell extends StatefulWidget {
  const DashboardShell({super.key});

  @override
  State<DashboardShell> createState() => _DashboardShellState();
}

class _DashboardShellState extends State<DashboardShell> {
  int index = 0;

  final screens = const [
    DashboardScreen(),
    PortfolioScreen(),
    AddAssetScreen(),
    AnalyticsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: screens[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.pie_chart_rounded), label: 'Portföy'),
          NavigationDestination(icon: Icon(Icons.add_circle_rounded), label: 'Ekle'),
          NavigationDestination(icon: Icon(Icons.show_chart_rounded), label: 'Analiz'),
          NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'Ayarlar'),
        ],
      ),
    );
  }
}
