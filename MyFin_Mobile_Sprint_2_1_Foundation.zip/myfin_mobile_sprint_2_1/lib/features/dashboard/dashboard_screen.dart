import 'package:flutter/material.dart';
import '../../app/theme/app_colors.dart';
import '../../core/widgets/metric_card.dart';
import '../../core/widgets/my_card.dart';
import '../../core/widgets/section_title.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.hawaiianOcean, AppColors.sky],
                ),
                borderRadius: BorderRadius.circular(17),
              ),
              child: const Icon(Icons.trending_up_rounded, color: Colors.white),
            ),
            const SizedBox(width: 14),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('MyFin', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                  Text('Smart Wealth Tracker', style: TextStyle(color: Colors.black54)),
                ],
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.notifications_none_rounded),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const MetricCard(
          title: 'Toplam Portföy',
          value: '₺318.387',
          subtitle: '▲ Bugün +%1,24',
          icon: Icons.account_balance_wallet_rounded,
        ),
        const SizedBox(height: 14),
        Row(
          children: const [
            Expanded(
              child: MetricCard(
                title: 'Bekleyen Kâr',
                value: '₺42.810',
                subtitle: '▲ +%8,7',
                icon: Icons.north_east_rounded,
              ),
            ),
            SizedBox(width: 14),
            Expanded(
              child: MetricCard(
                title: 'Net Servet',
                value: '₺318K',
                subtitle: 'Cloud synced',
                icon: Icons.diamond_rounded,
              ),
            ),
          ],
        ),
        const SectionTitle(title: 'Canlı Piyasa', action: 'Tümünü gör'),
        MyCard(
          child: Column(
            children: const [
              _MarketRow(name: 'USD/TRY', value: '₺32,14', change: '+0,42%'),
              Divider(height: 22),
              _MarketRow(name: 'EUR/TRY', value: '₺34,91', change: '-0,12%', positive: false),
              Divider(height: 22),
              _MarketRow(name: 'Gram Altın', value: '₺2.438', change: '+0,88%'),
            ],
          ),
        ),
        const SectionTitle(title: 'Portföy Dağılımı'),
        MyCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 160,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.hawaiianOcean.withOpacity(.08),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Text('Grafik alanı', style: TextStyle(color: Colors.black45)),
              ),
              const SizedBox(height: 16),
              const Text('Altın %55 • BIST %28 • Döviz %17'),
            ],
          ),
        ),
      ],
    );
  }
}

class _MarketRow extends StatelessWidget {
  final String name;
  final String value;
  final String change;
  final bool positive;

  const _MarketRow({
    required this.name,
    required this.value,
    required this.change,
    this.positive = true,
  });

  @override
  Widget build(BuildContext context) {
    final color = positive ? AppColors.success : AppColors.danger;

    return Row(
      children: [
        Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w700))),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(width: 12),
        Text(change, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
      ],
    );
  }
}
