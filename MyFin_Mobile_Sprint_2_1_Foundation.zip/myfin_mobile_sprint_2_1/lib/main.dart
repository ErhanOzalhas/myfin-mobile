import 'package:flutter/material.dart';
import 'app/myfin_app.dart';

void main() {
  runApp(const MyFinApp());
}
