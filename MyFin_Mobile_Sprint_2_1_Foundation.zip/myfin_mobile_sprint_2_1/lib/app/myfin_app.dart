import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import '../features/dashboard/dashboard_shell.dart';

class MyFinApp extends StatelessWidget {
  const MyFinApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyFin',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.system,
      home: const DashboardShell(),
    );
  }
}
