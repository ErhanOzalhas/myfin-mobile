import 'package:flutter/material.dart';

class AppColors {
  static const hawaiianOcean = Color(0xFF008DB9);
  static const navy = Color(0xFF0F172A);
  static const sky = Color(0xFF38BDF8);
  static const success = Color(0xFF16A34A);
  static const warning = Color(0xFFF97316);
  static const danger = Color(0xFFDC2626);
  static const background = Color(0xFFF7F9FC);
  static const darkBackground = Color(0xFF07111F);
}
